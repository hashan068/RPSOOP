import java.util.Random;
import java.util.Scanner;

public interface Player {
    void makeChoice();
    Gesture getChoice();
}
