import java.util.Scanner;
public class HumanPlayer implements Player {
    private Gesture choice;
    private Scanner scanner = new Scanner(System.in);

    @Override
    public void makeChoice() {
        System.out.print("Enter your choice (Rock, Paper, or Scissors): ");
        String userInput = scanner.nextLine().toUpperCase();
        while (!isValidChoice(userInput)) {
            System.out.println("Invalid choice. Please choose Rock, Paper, or Scissors.");
            System.out.print("Enter your choice (Rock, Paper, or Scissors): ");
            userInput = scanner.nextLine().toUpperCase();
        }
        choice = Gesture.valueOf(userInput);
    }

    @Override
    public Gesture getChoice() {
        return choice;
    }

    private boolean isValidChoice(String choice) {
        return choice.equals("ROCK") || choice.equals("PAPER") || choice.equals("SCISSORS");
    }
}