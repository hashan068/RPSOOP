import java.util.Scanner;

public class Game {
    private final Player user;
    private final Player computer;
    private int userWins = 0;
    private int computerWins = 0;
    private int draws = 0;

    public Game() {
        user = new HumanPlayer(); // Use HumanPlayer for user
        computer = new ComputerPlayer();
    }

    public void start() {
        System.out.println("Welcome to Rock-Paper-Scissors!");

        while (true) {
            // Get user and computer choices
            user.makeChoice();
            computer.makeChoice();

            // Determine the winner or if it's a draw
            Gesture userChoice = user.getChoice();
            Gesture computerChoice = computer.getChoice();

            System.out.println("Your choice: " + userChoice);
            System.out.println("Computer's choice: " + computerChoice);

            if (userChoice == computerChoice) {
                System.out.println("It's a draw!");
                draws++;
            } else if ((userChoice == Gesture.ROCK && computerChoice == Gesture.SCISSORS) ||
                    (userChoice == Gesture.PAPER && computerChoice == Gesture.ROCK) ||
                    (userChoice == Gesture.SCISSORS && computerChoice == Gesture.PAPER)) {
                System.out.println("You win!");
                userWins++;
            } else {
                System.out.println("Computer wins!");
                computerWins++;
            }

            // Ask the user if they want to play again
            System.out.print("Do you want to play again? (yes/no): ");
            Scanner scanner = new Scanner(System.in);
            String playAgain = scanner.nextLine().toLowerCase();
            if (!playAgain.equals("yes")) {
                break;
            }
        }

        // Display the overall results when the game ends
        displayResults();
    }

    private void displayResults() {
        System.out.println("Game Results:");
        System.out.println("User wins: " + userWins);
        System.out.println("Computer wins: " + computerWins);
        System.out.println("Draws: " + draws);
    }
}
