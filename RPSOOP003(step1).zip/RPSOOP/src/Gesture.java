public enum Gesture {
    ROCK, PAPER, SCISSORS;
}

